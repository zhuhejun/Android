package com.example.new4.bean;

public class Head {
    private String appId ;
    private String appSecret;

    public Head() {
        this.appId = "635139ffbf9045be9e94bae941d0a15d";
        this.appSecret = "68753e30f7e9bdc6f475784fa4a49c90be15a";
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }
}
